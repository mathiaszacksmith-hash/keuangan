# Keuangan Pribadi — Android Offline WebView

Aplikasi pencatatan keuangan pribadi berbasis Android WebView. Antarmuka dan aset web berjalan lokal sehingga aplikasi dapat dibuka tanpa koneksi internet.

## Fitur yang tersedia
- Saldo terpisah: Cash dan Bank.
- Pencatatan pemasukan, pengeluaran, dan transfer antar saldo.
- Edit dan hapus transaksi dari daftar transaksi.
- Riwayat berdasarkan bulan.
- Kategori pemasukan dan pengeluaran yang dapat ditambah/dihapus.
- Ringkasan dan laporan bulanan.
- Profil sederhana.
- Backup dan restore data JSON.
- Penyimpanan lokal melalui WebView localStorage.

## Membuka proyek
1. Unduh ZIP ini dan ekstrak.
2. Buka folder `keuangan-pribadi-android` melalui Android Studio.
3. Tunggu Gradle Sync selesai.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK hasil build tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Upload ke GitHub
Ekstrak ZIP, lalu upload seluruh isi folder proyek ke repository baru. Pastikan `settings.gradle`, `build.gradle`, `app/`, dan `README.md` berada di root repository.

## Catatan
- Data disimpan di perangkat, bukan server. Hapus data aplikasi dapat menghapus data keuangan jika belum membuat backup.
- Sinkronisasi Cloudflare/login cloud belum diaktifkan dalam paket dasar ini karena memerlukan konfigurasi Worker, database, dan kredensial.
- Anggaran masih berupa halaman awal; pengelolaan anggaran lengkap dapat ditambahkan pada iterasi berikutnya.
- Proyek ini adalah source Android Studio; APK perlu dibangun melalui Android Studio.
